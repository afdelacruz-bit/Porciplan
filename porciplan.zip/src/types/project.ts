/**
 * Types and models for PorciPlan
 */

export type ProductiveOrientation = 'cria' | 'ceba' | 'ciclo_completo';

export type TopographyType = 'plano' | 'leve_pendiente' | 'ondulado';

export type WaterSourceType = 'acueducto' | 'pozo_profundo' | 'quebrada_rio' | 'reservorio_lluvia';

export type BudgetCategory = 
  | 'obras_civiles'
  | 'equipamiento'
  | 'hidraulico_electrico'
  | 'bioseguridad_ambiental'
  | 'imprevistos';

export interface BudgetItem {
  id: string;
  category: BudgetCategory;
  concept: string;
  unit: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  notes?: string;
}

export interface ProjectCharacterization {
  id: string;
  name: string;
  producerName: string;
  location: string;
  orientation: ProductiveOrientation;
  animalCount: number;
  terrain: {
    length: number; // metros
    width: number;  // metros
    totalArea: number; // m2 (length * width)
    topography: TopographyType;
  };
  hasExistingInfrastructure: boolean;
  existingInfraDetails: string;
  availableBudget: number;
  currency: string;
  availableMaterials: string[];
  otherMaterials: string;
  waterSource: WaterSourceType;
  hasElectricity: boolean;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface TechnicalZoneSpec {
  id: string;
  name: string;
  category: 'produccion' | 'almacen' | 'sanidad_ambiental' | 'circulacion';
  description: string;
  orientationSuitability: ProductiveOrientation[];
  recommendedFloor: string;
  ventilationNotes: string;
  waterDrainageNotes: string;
  userCustomNotes?: string;
}

export interface PorciProject {
  characterization: ProjectCharacterization;
  budgetItems: BudgetItem[];
  technicalNotes: Record<string, string>;
  status: 'borrador' | 'en_planificacion' | 'validado';
}
