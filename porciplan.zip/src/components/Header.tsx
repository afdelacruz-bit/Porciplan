import React from 'react';
import { AppSection, SECTIONS } from '../types/navigation';
import { PorciProject } from '../types/project';
import { FolderKanban, Plus, FileText, CheckCircle2 } from 'lucide-react';

interface HeaderProps {
  currentSection: AppSection;
  onSelectSection: (section: AppSection) => void;
  activeProject: PorciProject;
  onOpenProjectManager: () => void;
  onNewProject: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentSection,
  onSelectSection,
  activeProject,
  onOpenProjectManager,
  onNewProject
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-purple-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onSelectSection('inicio')}
              className="flex items-center gap-2.5 text-left group transition-transform focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-600 rounded-lg p-1"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-700 to-purple-900 text-white flex items-center justify-center shadow-sm shadow-purple-900/20 group-hover:scale-105 transition-transform">
                <span className="font-bold text-lg tracking-tight">P</span>
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-purple-950 group-hover:text-purple-800 transition-colors">
                  Porci<span className="text-purple-600">Plan</span>
                </span>
                <span className="hidden sm:inline-block ml-2 text-xs font-medium text-purple-600/80 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200/60">
                  Planificación Porcina
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {SECTIONS.map((sec) => {
              const isActive = currentSection === sec.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => onSelectSection(sec.id)}
                  className={`px-3 py-1.5 text-xs xl:text-sm font-medium rounded-lg transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-purple-100/90 text-purple-950 font-semibold shadow-xs border border-purple-200'
                      : 'text-slate-600 hover:text-purple-900 hover:bg-purple-50/70'
                  }`}
                  title={sec.description}
                >
                  <span className="text-purple-500 font-mono text-[11px] font-semibold">{sec.number}</span>
                  <span>{sec.shortTitle}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions & Active Project Indicator */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Active Project pill / trigger */}
            <button
              onClick={onOpenProjectManager}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200/80 transition-colors"
              title="Cambiar o gestionar proyectos guardados"
            >
              <FolderKanban className="w-3.5 h-3.5 text-purple-600 shrink-0" />
              <span className="max-w-[130px] sm:max-w-[180px] truncate font-medium">
                {activeProject.characterization.name || 'Sin nombre'}
              </span>
            </button>

            {/* Quick New Project Button */}
            <button
              onClick={onNewProject}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-purple-700 hover:bg-purple-800 active:bg-purple-900 rounded-lg shadow-xs shadow-purple-900/10 transition-colors whitespace-nowrap"
              title="Crear un nuevo proyecto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Nuevo</span>
            </button>
          </div>

        </div>

        {/* Mobile Navigation Row */}
        <div className="lg:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-purple-100 no-scrollbar">
          {SECTIONS.map((sec) => {
            const isActive = currentSection === sec.id;
            return (
              <button
                key={sec.id}
                onClick={() => onSelectSection(sec.id)}
                className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap shrink-0 transition-colors ${
                  isActive
                    ? 'bg-purple-700 text-white font-medium'
                    : 'text-slate-600 hover:text-purple-900 hover:bg-purple-50'
                }`}
              >
                {sec.shortTitle}
              </button>
            );
          })}
        </div>

      </div>
    </header>
  );
};
