import React, { useState } from 'react';
import { PorciProject, BudgetCategory } from '../types/project';
import { MATERIAL_OPTIONS } from '../services/storage';
import { 
  Printer, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Building2, 
  Compass, 
  DollarSign, 
  ShieldCheck, 
  Sparkles,
  FileText,
  Calendar,
  Share2,
  Check
} from 'lucide-react';

interface ResultsSummaryViewProps {
  project: PorciProject;
}

export const ResultsSummaryView: React.FC<ResultsSummaryViewProps> = ({ project }) => {
  const [copied, setCopied] = useState(false);

  const char = project.characterization;
  const currency = char.currency || 'COP';
  const availableBudget = char.availableBudget || 0;
  const totalBudgeted = project.budgetItems.reduce((acc, item) => acc + item.totalCost, 0);
  const balance = availableBudget - totalBudgeted;
  const isDeficit = balance < 0;

  const orientationMap: Record<string, string> = {
    cria: 'Cría (Producción de Lechones Destetados)',
    ceba: 'Levante y Ceba (Finalización para Mercado)',
    ciclo_completo: 'Ciclo Completo (Parto a Finalización)'
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(project, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ficha_tecnica_${char.name.toLowerCase().replace(/\s+/g, '_')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportTextSummary = () => {
    const lines = [
      `=======================================================`,
      `PORCIPLAN - FICHA TÉCNICA Y ECONÓMICA DE INSTALACIONES`,
      `=======================================================`,
      `Proyecto: ${char.name}`,
      `Productor: ${char.producerName || 'No especificado'}`,
      `Ubicación: ${char.location || 'No especificada'}`,
      `Fecha: ${new Date().toLocaleDateString('es-ES')}`,
      ``,
      `1. CARACTERIZACIÓN DE LA EXPLOTACIÓN:`,
      `- Orientación Productiva: ${orientationMap[char.orientation] || char.orientation}`,
      `- Cantidad de animales: ${char.animalCount} cabezas`,
      `- Dimensiones de lote: ${char.terrain.length}m de largo × ${char.terrain.width}m de ancho`,
      `- Área total: ${char.terrain.totalArea} m²`,
      `- Topografía: ${char.terrain.topography}`,
      `- Infraestructura previa: ${char.hasExistingInfrastructure ? `Sí (${char.existingInfraDetails})` : 'No (Lote virgen)'}`,
      `- Fuente de agua: ${char.waterSource}`,
      `- Suministro eléctrico: ${char.hasElectricity ? 'Sí' : 'No'}`,
      ``,
      `2. MATERIALES DISPONIBLES:`,
      char.availableMaterials.map(m => `* ${m}`).join('\n'),
      char.otherMaterials ? `Otros: ${char.otherMaterials}` : '',
      ``,
      `3. BALANCE ECONÓMICO:`,
      `- Presupuesto Disponible: ${currency} $${availableBudget.toLocaleString()}`,
      `- Total Presupuestado: ${currency} $${totalBudgeted.toLocaleString()}`,
      `- Balance: ${currency} $${Math.abs(balance).toLocaleString()} (${balance >= 0 ? 'Superávit' : 'Déficit'})`,
      ``,
      `4. DESGLOSE DE RUBROS:`,
      ...project.budgetItems.map(it => `* [${it.category}] ${it.concept}: ${it.quantity} ${it.unit} x $${it.unitCost} = $${it.totalCost}`),
      ``,
      `=======================================================`,
      `Generado por PorciPlan - Herramienta de Planificación Porcina`
    ];

    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `resumen_${char.name.toLowerCase().replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const checklistItems = [
    {
      title: 'Orientación Bioclimática Este-Oeste',
      description: 'El eje longitudinal de las naves porcinas debe ubicarse de Este a Oeste para reducir calentamiento solar lateral.',
      status: 'verificado'
    },
    {
      title: 'Pendiente de Piso Sanitario (2-3%)',
      description: 'Superficie de concreto antideslizante con caída continua hacia las canaletas traseras de lavado.',
      status: 'verificado'
    },
    {
      title: 'Bioseguridad y Filtro de Acceso',
      description: 'Pediluvio en la puerta, cerramiento perimetral de protección y vestier para cambio obligatorio de calzado.',
      status: 'verificado'
    },
    {
      title: 'Manejo Responsable de Efluentes',
      description: 'Fosa impermeabilizada o estercolero ubicado a distancia segura de fuentes hídricas y a sotavento.',
      status: 'verificado'
    },
    {
      title: 'Reserva Hídrica Autónoma (Mínimo 48h)',
      description: 'Tanque elevado que garantice suministro ininterrumpido a comederos y bebederos tipo chupón.',
      status: 'verificado'
    }
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      
      {/* Header & Print actions */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-purple-100 shadow-xs no-print">
        <div>
          <span className="text-xs font-semibold text-purple-700 tracking-wider uppercase">Paso 06</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Resultados y Ficha del Proyecto</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Revisión integral del proyecto porcino, balance económico y checklist de buenas prácticas constructivas.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl bg-purple-700 hover:bg-purple-800 text-white shadow-xs transition-colors flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir Ficha Técnica</span>
          </button>
          
          <button
            onClick={handleExportTextSummary}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-purple-200 text-purple-900 bg-purple-50 hover:bg-purple-100 transition-colors flex items-center gap-1.5"
            title="Descargar archivo de texto simple"
          >
            <FileText className="w-4 h-4 text-purple-600" />
            <span>Descargar Resumen</span>
          </button>

          <button
            onClick={handleExportJSON}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors flex items-center gap-1.5"
            title="Exportar archivo de datos JSON"
          >
            <Download className="w-4 h-4" />
            <span>Exportar JSON</span>
          </button>
        </div>
      </div>

      {/* PRINTABLE DOSSIER CARD */}
      <div className="bg-white rounded-3xl border border-purple-200/90 shadow-lg p-6 sm:p-10 space-y-8 print:border-none print:shadow-none print:p-0">
        
        {/* Document Header */}
        <div className="flex flex-wrap items-start justify-between gap-4 border-b-2 border-purple-900 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-purple-900 text-white flex items-center justify-center font-bold text-sm">
                P
              </div>
              <span className="text-xl font-bold text-purple-950">PorciPlan</span>
              <span className="text-xs text-purple-700 bg-purple-50 px-2 py-0.5 rounded font-medium border border-purple-200">
                Ficha Técnica de Instalaciones
              </span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 pt-2">{char.name}</h2>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
              {char.producerName && <span>Productor: <strong>{char.producerName}</strong></span>}
              {char.location && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>Ubicación: <strong>{char.location}</strong></span>
                </>
              )}
              <span aria-hidden="true">·</span>
              <span>Fecha: {new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
            </div>
          </div>

          <div className="text-right sm:text-right">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-600 block">Estado del Proyecto</span>
            <span className="inline-block mt-0.5 px-3 py-1 rounded-full bg-purple-100 text-purple-900 font-bold text-xs">
              Planificación Técnica Inicial
            </span>
          </div>
        </div>

        {/* 1. Project Characterization Summary Table */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-purple-950 uppercase tracking-wider flex items-center gap-2">
            <Building2 className="w-4 h-4 text-purple-700" />
            <span>1. Parámetros de la Explotación Porcina</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-purple-50/50 border border-purple-100 text-xs">
            <div>
              <span className="text-slate-500 block">Orientación Productiva:</span>
              <span className="font-bold text-purple-950 text-sm">
                {orientationMap[char.orientation] || char.orientation}
              </span>
            </div>

            <div>
              <span className="text-slate-500 block">Capacidad Proyectada:</span>
              <span className="font-bold text-purple-950 text-sm font-mono tabular-nums">
                {char.animalCount} cerdos
              </span>
            </div>

            <div>
              <span className="text-slate-500 block">Dimensiones del Terreno:</span>
              <span className="font-bold text-purple-950 text-sm font-mono tabular-nums">
                {char.terrain.length}m × {char.terrain.width}m
              </span>
              <span className="text-[11px] text-slate-500 block">Área: {char.terrain.totalArea} m²</span>
            </div>

            <div>
              <span className="text-slate-500 block">Topografía:</span>
              <span className="font-bold text-purple-950 text-sm capitalize">
                {char.terrain.topography.replace('_', ' ')}
              </span>
            </div>

            <div>
              <span className="text-slate-500 block">Infraestructura Previa:</span>
              <span className="font-bold text-purple-950 text-sm">
                {char.hasExistingInfrastructure ? 'Existente' : 'Predio Nuevo'}
              </span>
              {char.existingInfraDetails && (
                <span className="text-[11px] text-slate-500 block line-clamp-1">{char.existingInfraDetails}</span>
              )}
            </div>

            <div>
              <span className="text-slate-500 block">Fuente de Agua:</span>
              <span className="font-bold text-purple-950 text-sm capitalize">
                {char.waterSource.replace('_', ' ')}
              </span>
            </div>

            <div>
              <span className="text-slate-500 block">Energía Eléctrica:</span>
              <span className="font-bold text-purple-950 text-sm">
                {char.hasElectricity ? 'Disponible' : 'No disponible'}
              </span>
            </div>

            <div>
              <span className="text-slate-500 block">Presupuesto Inicial:</span>
              <span className="font-bold text-purple-950 text-sm font-mono tabular-nums">
                {currency} ${Number(availableBudget).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Materials summary line */}
          <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs flex flex-wrap items-center gap-2">
            <span className="font-semibold text-slate-700">Materiales locales disponibles:</span>
            {char.availableMaterials.length === 0 ? (
              <span className="italic text-slate-400">Sin registrar</span>
            ) : (
              char.availableMaterials.map((mId) => {
                const opt = MATERIAL_OPTIONS.find(o => o.id === mId);
                return (
                  <span key={mId} className="bg-purple-100 text-purple-900 px-2.5 py-0.5 rounded-md font-medium text-[11px]">
                    {opt ? opt.label.split('(')[0].trim() : mId}
                  </span>
                );
              })
            )}
            {char.otherMaterials && (
              <span className="text-slate-500 text-[11px]">({char.otherMaterials})</span>
            )}
          </div>
        </div>

        {/* 2. Economic Balance & Category Distribution */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-purple-950 uppercase tracking-wider flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-purple-700" />
            <span>2. Balance Financiero y Estimación de Inversión</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-purple-50/70 border border-purple-100">
              <span className="text-xs text-slate-500">Presupuesto Disponible:</span>
              <div className="text-lg font-bold text-purple-950 font-mono tabular-nums mt-0.5">
                {currency} ${availableBudget.toLocaleString()}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-purple-50/70 border border-purple-100">
              <span className="text-xs text-slate-500">Costo Estimado en Rubros:</span>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                {currency} ${totalBudgeted.toLocaleString()}
              </div>
            </div>

            <div className={`p-4 rounded-xl border ${
              isDeficit ? 'bg-rose-50 text-rose-950 border-rose-200' : 'bg-emerald-50 text-emerald-950 border-emerald-200'
            }`}>
              <span className="text-xs font-semibold">
                {isDeficit ? 'Déficit Estimado:' : 'Margen Disponible (Superávit):'}
              </span>
              <div className="text-lg font-bold font-mono tabular-nums mt-0.5">
                {currency} ${Math.abs(balance).toLocaleString()}
              </div>
            </div>
          </div>

          {/* Budget items breakdown table */}
          {project.budgetItems.length > 0 && (
            <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200 text-[10px] uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Rubro</th>
                    <th className="py-2.5 px-3">Categoría</th>
                    <th className="py-2.5 px-2 text-right">Cant.</th>
                    <th className="py-2.5 px-3 text-right">Unitario</th>
                    <th className="py-2.5 px-3 text-right">Total ({currency})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {project.budgetItems.map(it => (
                    <tr key={it.id}>
                      <td className="py-2 px-3 font-medium text-slate-900">{it.concept}</td>
                      <td className="py-2 px-3 text-slate-500 capitalize">{it.category.replace('_', ' ')}</td>
                      <td className="py-2 px-2 text-right font-mono tabular-nums">{it.quantity} {it.unit}</td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">${Number(it.unitCost).toLocaleString()}</td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                        ${Number(it.totalCost).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* 3. Zootechnical Checklist for Construction */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-purple-950 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-purple-700" />
            <span>3. Checklist de Criterios Básicos de Construcción Porcina</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {checklistItems.map((chk, i) => (
              <div key={i} className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-xs font-bold text-slate-900">{chk.title}</span>
                </div>
                <p className="text-[11px] text-slate-500 pl-6 leading-relaxed">
                  {chk.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Future Readiness Roadmap Banner */}
        <div className="p-5 rounded-2xl bg-purple-50/70 border border-purple-200 space-y-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-purple-950">
            <Sparkles className="w-4 h-4 text-purple-700" />
            <span>Fase 2: Motor de Dimensionamiento Zootécnico Asistido por IA</span>
          </div>
          <p className="text-slate-600 leading-relaxed">
            La información registrada en esta ficha queda guardada en el almacenamiento local de tu navegador y estructura los datos necesarios 
            para que el motor matemático de zootecnia porcina determine con precisión: áreas por animal (m²/cabeza), dimensiones exactas de comederos tolva, 
            volumen del estercolero y recomendaciones contextuales mediante el modelo Gemini en la siguiente iteración.
          </p>
        </div>

        {/* Footer print note */}
        <div className="pt-4 border-t border-slate-200 text-center text-[10px] text-slate-400">
          PorciPlan · Sistema de Planificación Técnica y Económica para Pequeños y Medianos Productores Porcinos
        </div>

      </div>

    </div>
  );
};
