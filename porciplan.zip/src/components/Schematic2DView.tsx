import React, { useState, useId } from 'react';
import { PorciProject } from '../types/project';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Grid, 
  Layers, 
  Compass, 
  Info, 
  Printer, 
  CheckCircle2, 
  ArrowRight,
  ShieldCheck,
  Maximize2
} from 'lucide-react';

interface Schematic2DViewProps {
  project: PorciProject;
  onNavigateToNext: () => void;
}

interface SelectedZoneInfo {
  title: string;
  category: string;
  dimensionsText: string;
  description: string;
  recommendations: string[];
}

export const Schematic2DView: React.FC<Schematic2DViewProps> = ({
  project,
  onNavigateToNext
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showDimensions, setShowDimensions] = useState<boolean>(true);
  const [showBiosecurityRing, setShowBiosecurityRing] = useState<boolean>(true);
  const [selectedZone, setSelectedZone] = useState<SelectedZoneInfo | null>(null);

  const patternId = useId();

  const terrain = project.characterization.terrain;
  const orientation = project.characterization.orientation;
  const animalCount = project.characterization.animalCount;

  // Real world dimensions (fallback to default if invalid)
  const lotLength = terrain.length > 0 ? terrain.length : 40;
  const lotWidth = terrain.width > 0 ? terrain.width : 25;

  // ViewBox & Canvas scale calculations
  // Fixed canvas coordinate system (e.g. 800 x 500)
  const canvasWidth = 840;
  const canvasHeight = 540;
  const margin = 50;

  const drawableWidth = canvasWidth - margin * 2;
  const drawableHeight = canvasHeight - margin * 2;

  // Determine scale (pixels per meter)
  const scaleX = drawableWidth / lotLength;
  const scaleY = drawableHeight / lotWidth;
  const scale = Math.min(scaleX, scaleY);

  const lotPixelWidth = lotLength * scale;
  const lotPixelHeight = lotWidth * scale;

  const lotStartX = (canvasWidth - lotPixelWidth) / 2;
  const lotStartY = (canvasHeight - lotPixelHeight) / 2;

  // Facilities positions proportional to lot
  // Swine Pavilion: oriented East - West in the center of the lot
  const pavilionLengthMeters = Math.min(lotLength * 0.6, Math.max(12, animalCount * 0.4));
  const pavilionWidthMeters = Math.min(lotWidth * 0.45, 10);
  
  const pavilionPixelW = pavilionLengthMeters * scale;
  const pavilionPixelH = pavilionWidthMeters * scale;
  const pavilionX = lotStartX + (lotPixelWidth - pavilionPixelW) / 2;
  const pavilionY = lotStartY + (lotPixelHeight - pavilionPixelH) / 2 - 10;

  // Feed Warehouse (near entrance and pavilion)
  const warehouseW = 6 * scale;
  const warehouseH = 4 * scale;
  const warehouseX = pavilionX - warehouseW - 12;
  const warehouseY = pavilionY;

  // Waste / Estercolero (downhill at bottom corner)
  const wasteW = 7 * scale;
  const wasteH = 5 * scale;
  const wasteX = lotStartX + lotPixelWidth - wasteW - 20;
  const wasteY = lotStartY + lotPixelHeight - wasteH - 20;

  // Sanitary entrance / Pediluvio (at main gate)
  const gateW = 8 * scale;
  const gateH = 3.5 * scale;
  const gateX = lotStartX + 20;
  const gateY = lotStartY + 20;

  // Water tank reserve
  const tankRadius = 2.2 * scale;
  const tankX = pavilionX + pavilionPixelW + 25;
  const tankY = pavilionY + 20;

  const handleZoneClick = (info: SelectedZoneInfo) => {
    setSelectedZone(info);
  };

  const handleZoom = (delta: number) => {
    setZoomLevel(prev => Math.min(2.0, Math.max(0.7, prev + delta)));
  };

  const resetView = () => {
    setZoomLevel(1);
    setSelectedZone(null);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-12">
      
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-purple-100 shadow-xs">
        <div>
          <span className="text-xs font-semibold text-purple-700 tracking-wider uppercase">Paso 04</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Diseño Esquemático 2D de la Granja</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Plano arquitectónico esquemático del predio ({lotLength}m × {lotWidth}m, {terrain.totalArea} m²), 
            con zonificación bioclimática Este-Oeste y franjas de bioseguridad.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-purple-200 text-purple-900 bg-purple-50 hover:bg-purple-100 transition-colors flex items-center gap-1.5"
            title="Imprimir plano de la granja"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">Imprimir Plano</span>
          </button>
          <button
            onClick={onNavigateToNext}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-xl shadow-xs transition-colors flex items-center gap-2"
          >
            <span>Ir a Presupuesto</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Toolbar & Canvas Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Main Canvas Area */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-purple-100 shadow-xs p-4 flex flex-col justify-between space-y-4">
          
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2 bg-purple-50/60 rounded-xl border border-purple-100 text-xs">
            {/* View Layer Toggles */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowGrid(!showGrid)}
                className={`px-2.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
                  showGrid ? 'bg-purple-700 text-white' : 'text-slate-600 hover:bg-purple-100/60'
                }`}
                title="Mostrar cuadrícula métrica"
              >
                <Grid className="w-3.5 h-3.5" />
                <span>Cuadrícula</span>
              </button>

              <button
                onClick={() => setShowDimensions(!showDimensions)}
                className={`px-2.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
                  showDimensions ? 'bg-purple-700 text-white' : 'text-slate-600 hover:bg-purple-100/60'
                }`}
                title="Mostrar cotas y medidas"
              >
                <span>Cotas (m)</span>
              </button>

              <button
                onClick={() => setShowBiosecurityRing(!showBiosecurityRing)}
                className={`px-2.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
                  showBiosecurityRing ? 'bg-purple-700 text-white' : 'text-slate-600 hover:bg-purple-100/60'
                }`}
                title="Mostrar cerca perimetral y buffer"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Bioseguridad</span>
              </button>
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-purple-200">
              <button
                onClick={() => handleZoom(-0.15)}
                className="p-1.5 text-slate-600 hover:text-purple-700 hover:bg-purple-50 rounded-md transition-colors"
                title="Alejar"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-mono text-[11px] text-purple-950 font-bold min-w-[45px] text-center">
                {Math.round(zoomLevel * 100)}%
              </span>
              <button
                onClick={() => handleZoom(0.15)}
                className="p-1.5 text-slate-600 hover:text-purple-700 hover:bg-purple-50 rounded-md transition-colors"
                title="Acercar"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={resetView}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md transition-colors border-l border-slate-200 ml-0.5"
                title="Reiniciar vista"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* SVG Canvas Container */}
          <div className="relative w-full aspect-[16/10] bg-[#faf8fc] rounded-xl border border-purple-200/80 overflow-hidden flex items-center justify-center shadow-inner">
            
            {/* Cardinal orientation marker (Rosa de los vientos) in corner */}
            <div className="absolute top-3 right-3 z-10 pointer-events-none bg-white/90 backdrop-blur-xs p-2 rounded-xl border border-purple-200/80 shadow-xs flex flex-col items-center">
              <div className="text-[10px] font-bold text-red-600 font-mono tracking-wider">NORTE (N)</div>
              <div className="w-6 h-6 my-0.5 relative flex items-center justify-center">
                <div className="w-0.5 h-6 bg-slate-300 absolute" />
                <div className="w-6 h-0.5 bg-slate-300 absolute" />
                <div className="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-b-[10px] border-b-red-600 absolute top-0" />
              </div>
              <div className="text-[9px] font-semibold text-purple-900 tracking-tight">Eje E ↔ O</div>
            </div>

            {/* Scale badge in bottom-left corner */}
            <div className="absolute bottom-3 left-3 z-10 pointer-events-none bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-purple-200 text-[10px] font-mono text-purple-900">
              Escala: ~{(scale).toFixed(1)} px / metro
            </div>

            <svg
              viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
              className="w-full h-full cursor-crosshair select-none transition-transform duration-200 ease-out"
              style={{ transform: `scale(${zoomLevel})` }}
            >
              <defs>
                <pattern id={patternId} width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e9d5ff" strokeWidth="0.5" />
                </pattern>
                
                {/* Marker for dimension arrows */}
                <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#6b21a8" />
                </marker>
              </defs>

              {/* Grid Background */}
              {showGrid && (
                <rect width={canvasWidth} height={canvasHeight} fill={`url(#${patternId})`} />
              )}

              {/* Perimeter Buffer / Sanitary Ring */}
              {showBiosecurityRing && (
                <rect
                  x={lotStartX - 15}
                  y={lotStartY - 15}
                  width={lotPixelWidth + 30}
                  height={lotPixelHeight + 30}
                  fill="none"
                  stroke="#a855f7"
                  strokeWidth="1.5"
                  strokeDasharray="6 4"
                  rx="12"
                />
              )}

              {/* Main Lot Boundary (Predio) */}
              <rect
                x={lotStartX}
                y={lotStartY}
                width={lotPixelWidth}
                height={lotPixelHeight}
                fill="#ffffff"
                stroke="#4a044e"
                strokeWidth="2.5"
                rx="6"
              />

              {/* Lot Ground Texture / Grass tint */}
              <rect
                x={lotStartX}
                y={lotStartY}
                width={lotPixelWidth}
                height={lotPixelHeight}
                fill="#fdf4ff"
                opacity="0.4"
                rx="6"
              />

              {/* External Dimensions / Cotas */}
              {showDimensions && (
                <g className="text-[11px] font-mono font-bold fill-purple-900">
                  {/* Top dimension (Length) */}
                  <line
                    x1={lotStartX}
                    y1={lotStartY - 24}
                    x2={lotStartX + lotPixelWidth}
                    y2={lotStartY - 24}
                    stroke="#7e22ce"
                    strokeWidth="1.5"
                    markerStart="url(#arrow)"
                    markerEnd="url(#arrow)"
                  />
                  <line x1={lotStartX} y1={lotStartY - 30} x2={lotStartX} y2={lotStartY} stroke="#7e22ce" strokeWidth="0.8" strokeDasharray="2 2" />
                  <line x1={lotStartX + lotPixelWidth} y1={lotStartY - 30} x2={lotStartX + lotPixelWidth} y2={lotStartY} stroke="#7e22ce" strokeWidth="0.8" strokeDasharray="2 2" />
                  <text x={lotStartX + lotPixelWidth / 2} y={lotStartY - 30} textAnchor="middle" fill="#581c87" fontSize="12">
                    Largo del predio: {lotLength} m
                  </text>

                  {/* Left dimension (Width) */}
                  <line
                    x1={lotStartX - 24}
                    y1={lotStartY}
                    x2={lotStartX - 24}
                    y2={lotStartY + lotPixelHeight}
                    stroke="#7e22ce"
                    strokeWidth="1.5"
                    markerStart="url(#arrow)"
                    markerEnd="url(#arrow)"
                  />
                  <line x1={lotStartX - 30} y1={lotStartY} x2={lotStartX} y2={lotStartY} stroke="#7e22ce" strokeWidth="0.8" strokeDasharray="2 2" />
                  <line x1={lotStartX - 30} y1={lotStartY + lotPixelHeight} x2={lotStartX} y2={lotStartY + lotPixelHeight} stroke="#7e22ce" strokeWidth="0.8" strokeDasharray="2 2" />
                  <text
                    x={-(lotStartY + lotPixelHeight / 2)}
                    y={lotStartX - 30}
                    transform="rotate(-90)"
                    textAnchor="middle"
                    fill="#581c87"
                    fontSize="12"
                  >
                    Ancho: {lotWidth} m
                  </text>
                </g>
              )}

              {/* Entrance Gate & Sanitary Filter */}
              <g
                className="cursor-pointer transition-opacity hover:opacity-85"
                onClick={() => handleZoneClick({
                  title: 'Filtro Sanitario y Pediluvio de Entrada',
                  category: 'Bioseguridad y Acceso',
                  dimensionsText: `${(gateW / scale).toFixed(1)}m × ${(gateH / scale).toFixed(1)}m`,
                  description: 'Acceso principal de la granja con foso de desinfección de calzado, rodaluvio para llantas de vehículos y estación de lavado de manos.',
                  recommendations: [
                    'Ubicado en el perímetro de acceso, obligando a toda persona a pasar por el pediluvio.',
                    'Mantener solución desinfectante activa (amonio cuaternario, yodo o cal).',
                    'Vestier con casilleros y botas de uso exclusivo para las naves porcinas.'
                  ]
                })}
              >
                <rect
                  x={gateX}
                  y={gateY}
                  width={gateW}
                  height={gateH}
                  fill="#f3e8ff"
                  stroke="#7e22ce"
                  strokeWidth="1.5"
                  rx="4"
                />
                <text x={gateX + gateW / 2} y={gateY + gateH / 2 + 4} textAnchor="middle" fontSize="10" fontWeight="bold" fill="#581c87">
                  Acceso / Pediluvio
                </text>
              </g>

              {/* Feed Warehouse / Bodega */}
              <g
                className="cursor-pointer transition-opacity hover:opacity-85"
                onClick={() => handleZoneClick({
                  title: 'Bodega de Alimento Concentrado',
                  category: 'Almacenamiento y Logística',
                  dimensionsText: `${(warehouseW / scale).toFixed(1)}m × ${(warehouseH / scale).toFixed(1)}m`,
                  description: 'Bodega seca, ventilada y protegida contra roedores y aves. Permite descargar alimento sin ingresar a las naves de animales.',
                  recommendations: [
                    'Piso de concreto sobreelevado y estibas de madera/plástico (separación de 15cm del piso).',
                    'Almacenar inventario suficiente para 15 a 20 días de consumo.',
                    'Rotación de alimento bajo principio PEPS (Primero en Entrar, Primero en Salir).'
                  ]
                })}
              >
                <rect
                  x={warehouseX}
                  y={warehouseY}
                  width={warehouseW}
                  height={warehouseH}
                  fill="#e9d5ff"
                  stroke="#6b21a8"
                  strokeWidth="1.8"
                  rx="4"
                />
                <text x={warehouseX + warehouseW / 2} y={warehouseY + warehouseH / 2 + 4} textAnchor="middle" fontSize="10" fontWeight="bold" fill="#3b0764">
                  Bodega Alimento
                </text>
              </g>

              {/* Water Storage Tank */}
              <g
                className="cursor-pointer transition-opacity hover:opacity-85"
                onClick={() => handleZoneClick({
                  title: 'Tanque Elevado de Reserva Hídrica',
                  category: 'Red Hidráulica',
                  dimensionsText: 'Capacidad mínima 2.000 L',
                  description: 'Garantiza suministro continuo y constante de agua potable fresca para los cerdos y lavado de instalaciones.',
                  recommendations: [
                    'Autonomía de mínimo 48 a 72 horas para evitar desabastecimiento.',
                    'Conectado a la red de bebederos tipo chupón con regulador de presión.',
                    'Protegido de la radiación solar directa para evitar calentamiento del agua.'
                  ]
                })}
              >
                <circle
                  cx={tankX}
                  cy={tankY}
                  r={tankRadius}
                  fill="#dbeafe"
                  stroke="#2563eb"
                  strokeWidth="2"
                />
                <text x={tankX} y={tankY + 4} textAnchor="middle" fontSize="9" fontWeight="bold" fill="#1e40af">
                  Tanque H₂O
                </text>
              </g>

              {/* Waste Treatment: Estercolero / Fosa Séptica */}
              <g
                className="cursor-pointer transition-opacity hover:opacity-85"
                onClick={() => handleZoneClick({
                  title: 'Estercolero y Trampa de Porcinaza',
                  category: 'Manejo Sanitario y Ambiental',
                  dimensionsText: `${(wasteW / scale).toFixed(1)}m × ${(wasteH / scale).toFixed(1)}m`,
                  description: 'Depósito impermeable con trampa de sedimentación para fermentación aerobia/anaerobia de estiércol y aprovechamiento como abono.',
                  recommendations: [
                    'Ubicado en la cota más baja del terreno y a sotavento de los galpones y viviendas.',
                    'Distancia mínima de 25m a cualquier cuerpo de agua o pozo para evitar contaminación.',
                    'Techo o cobertura para evitar ingreso excesivo de aguas lluvias que rebosen la fosa.'
                  ]
                })}
              >
                <rect
                  x={wasteX}
                  y={wasteY}
                  width={wasteW}
                  height={wasteH}
                  fill="#fed7aa"
                  stroke="#ea580c"
                  strokeWidth="1.8"
                  rx="4"
                />
                <text x={wasteX + wasteW / 2} y={wasteY + wasteH / 2 + 4} textAnchor="middle" fontSize="10" fontWeight="bold" fill="#7c2d12">
                  Estercolero / Fosa
                </text>
              </g>

              {/* MAIN SWINE PAVILION (Nave Porcina) */}
              <g
                className="cursor-pointer"
                onClick={() => handleZoneClick({
                  title: orientation === 'cria' 
                    ? 'Nave Porcina: Maternidad y Gestación' 
                    : orientation === 'ceba' 
                    ? 'Nave Porcina: Corrales de Ceba' 
                    : 'Nave Porcina: Ciclo Completo',
                  category: 'Instalación Productiva Principal',
                  dimensionsText: `${pavilionLengthMeters.toFixed(1)}m × ${pavilionWidthMeters.toFixed(1)}m (~${(pavilionLengthMeters * pavilionWidthMeters).toFixed(0)} m²)`,
                  description: 'Galpón principal con eje longitudinal orientado Este-Oeste. Diseñado con muros bajos de 1.0m, aleros anchos y piso con pendiente hacia canal de evacuación.',
                  recommendations: [
                    'Orientación longitudinal E-O para reducir exposición solar directa.',
                    'Pendiente de pisos entre 2.5% y 3% dirigida hacia canaletas de drenaje.',
                    'Separación clara entre pasillo limpio de alimentación y canal sucio de lavado.'
                  ]
                })}
              >
                {/* Roof & Base Outline */}
                <rect
                  x={pavilionX}
                  y={pavilionY}
                  width={pavilionPixelW}
                  height={pavilionPixelH}
                  fill="#ffffff"
                  stroke="#3b0764"
                  strokeWidth="2.5"
                  rx="6"
                  className="filter drop-shadow-xs"
                />

                {/* Central Management Corridor (Pasillo Central) */}
                <rect
                  x={pavilionX}
                  y={pavilionY + pavilionPixelH * 0.4}
                  width={pavilionPixelW}
                  height={pavilionPixelH * 0.2}
                  fill="#f3e8ff"
                  stroke="#c084fc"
                  strokeWidth="1"
                />
                <text
                  x={pavilionX + pavilionPixelW / 2}
                  y={pavilionY + pavilionPixelH * 0.5 + 3}
                  textAnchor="middle"
                  fontSize="9"
                  fontWeight="bold"
                  fill="#6b21a8"
                >
                  Pasillo de Manejo y Alimentación
                </text>

                {/* Pens / Corrales layout depending on orientation */}
                {orientation === 'cria' ? (
                  <>
                    {/* Top Row: Maternidades */}
                    <g>
                      <rect x={pavilionX} y={pavilionY} width={pavilionPixelW * 0.5} height={pavilionPixelH * 0.4} fill="#fae8ff" stroke="#e879f9" strokeWidth="1" />
                      <text x={pavilionX + pavilionPixelW * 0.25} y={pavilionY + pavilionPixelH * 0.22} textAnchor="middle" fontSize="9" fontWeight="bold" fill="#86198f">
                        Salas de Maternidad (Parideras)
                      </text>

                      <rect x={pavilionX + pavilionPixelW * 0.5} y={pavilionY} width={pavilionPixelW * 0.5} height={pavilionPixelH * 0.4} fill="#fdf4ff" stroke="#d946ef" strokeWidth="1" />
                      <text x={pavilionX + pavilionPixelW * 0.75} y={pavilionY + pavilionPixelH * 0.22} textAnchor="middle" fontSize="9" fontWeight="bold" fill="#86198f">
                        Lechoneras / Calor
                      </text>
                    </g>

                    {/* Bottom Row: Gestación */}
                    <g>
                      <rect x={pavilionX} y={pavilionY + pavilionPixelH * 0.6} width={pavilionPixelW} height={pavilionPixelH * 0.4} fill="#f5f3ff" stroke="#a78bfa" strokeWidth="1" />
                      <text x={pavilionX + pavilionPixelW * 0.5} y={pavilionY + pavilionPixelH * 0.82} textAnchor="middle" fontSize="9" fontWeight="bold" fill="#5b21b6">
                        Corrales de Cerdas en Gestación y Monta
                      </text>
                    </g>
                  </>
                ) : orientation === 'ceba' ? (
                  <>
                    {/* Top and Bottom Pen Modules for Grow-Finish */}
                    {[0, 1, 2, 3].map((i) => {
                      const penW = pavilionPixelW / 4;
                      return (
                        <g key={`pen_${i}`}>
                          {/* Top pen */}
                          <rect
                            x={pavilionX + i * penW}
                            y={pavilionY}
                            width={penW}
                            height={pavilionPixelH * 0.4}
                            fill="#faf5ff"
                            stroke="#d8b4fe"
                            strokeWidth="1"
                          />
                          <text
                            x={pavilionX + i * penW + penW / 2}
                            y={pavilionY + pavilionPixelH * 0.22}
                            textAnchor="middle"
                            fontSize="9"
                            fontWeight="bold"
                            fill="#581c87"
                          >
                            Corral Ceba {i + 1}
                          </text>

                          {/* Bottom pen */}
                          <rect
                            x={pavilionX + i * penW}
                            y={pavilionY + pavilionPixelH * 0.6}
                            width={penW}
                            height={pavilionPixelH * 0.4}
                            fill="#faf5ff"
                            stroke="#d8b4fe"
                            strokeWidth="1"
                          />
                          <text
                            x={pavilionX + i * penW + penW / 2}
                            y={pavilionY + pavilionPixelH * 0.82}
                            textAnchor="middle"
                            fontSize="9"
                            fontWeight="bold"
                            fill="#581c87"
                          >
                            Corral Ceba {i + 5}
                          </text>
                        </g>
                      );
                    })}
                  </>
                ) : (
                  <>
                    {/* Ciclo Completo: 4 Stages */}
                    {[
                      { label: 'Gestación', fill: '#f5f3ff' },
                      { label: 'Maternidad', fill: '#fae8ff' },
                      { label: 'Destete / Precebo', fill: '#ede9fe' },
                      { label: 'Ceba Final', fill: '#f3e8ff' }
                    ].map((stg, idx) => {
                      const colW = pavilionPixelW / 4;
                      return (
                        <g key={stg.label}>
                          <rect
                            x={pavilionX + idx * colW}
                            y={pavilionY}
                            width={colW}
                            height={pavilionPixelH * 0.4}
                            fill={stg.fill}
                            stroke="#c084fc"
                            strokeWidth="1"
                          />
                          <rect
                            x={pavilionX + idx * colW}
                            y={pavilionY + pavilionPixelH * 0.6}
                            width={colW}
                            height={pavilionPixelH * 0.4}
                            fill={stg.fill}
                            stroke="#c084fc"
                            strokeWidth="1"
                          />
                          <text
                            x={pavilionX + idx * colW + colW / 2}
                            y={pavilionY + pavilionPixelH * 0.22}
                            textAnchor="middle"
                            fontSize="8.5"
                            fontWeight="bold"
                            fill="#4c1d95"
                          >
                            {stg.label}
                          </text>
                          <text
                            x={pavilionX + idx * colW + colW / 2}
                            y={pavilionY + pavilionPixelH * 0.82}
                            textAnchor="middle"
                            fontSize="8.5"
                            fontWeight="bold"
                            fill="#4c1d95"
                          >
                            {stg.label} (B)
                          </text>
                        </g>
                      );
                    })}
                  </>
                )}

                {/* Drainage Gutter (Canaleta de Porcinaza) line at bottom of pavilion */}
                <line
                  x1={pavilionX}
                  y1={pavilionY + pavilionPixelH}
                  x2={pavilionX + pavilionPixelW}
                  y2={pavilionY + pavilionPixelH}
                  stroke="#ea580c"
                  strokeWidth="3"
                  strokeDasharray="4 2"
                />
              </g>

              {/* Effluent pipe to estercolero */}
              <path
                d={`M ${pavilionX + pavilionPixelW} ${pavilionY + pavilionPixelH} Q ${wasteX - 20} ${pavilionY + pavilionPixelH + 20} ${wasteX} ${wasteY + wasteH / 2}`}
                fill="none"
                stroke="#ea580c"
                strokeWidth="1.5"
                strokeDasharray="4 3"
              />
            </svg>
          </div>

          {/* Quick Legend Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-slate-600 border-t border-purple-50">
            <div className="flex flex-wrap items-center gap-3">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-purple-700 inline-block" />
                <span>Nave Porcina (E-O)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-purple-200 inline-block" />
                <span>Bodega Alimento</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-orange-300 inline-block" />
                <span>Estercolero / Fosa</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-blue-200 inline-block" />
                <span>Tanque Agua</span>
              </span>
            </div>
            <span className="text-[11px] text-purple-700 italic">
              Haz clic en cualquier área para ver su ficha técnica.
            </span>
          </div>

        </div>

        {/* Zone Details / Inspector Sidebar */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-2xl border border-purple-100 shadow-xs p-6 space-y-4 min-h-[380px]">
            <div className="flex items-center justify-between border-b border-purple-50 pb-3">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-purple-700" />
                <h2 className="text-sm font-bold text-purple-950">Ficha Técnica de Zona</h2>
              </div>
              <span className="text-xs text-slate-400">Esquema 2D</span>
            </div>

            {selectedZone ? (
              <div className="space-y-4">
                <div>
                  <span className="text-[10px] uppercase tracking-wider font-semibold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-md">
                    {selectedZone.category}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-1">{selectedZone.title}</h3>
                  <div className="text-xs font-mono font-semibold text-purple-900 mt-0.5">
                    Dimensiones aprox: {selectedZone.dimensionsText}
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {selectedZone.description}
                </p>

                <div className="space-y-2 pt-2 border-t border-purple-50">
                  <span className="text-xs font-bold text-purple-950 block">Buenas Prácticas Zootécnicas:</span>
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {selectedZone.recommendations.map((rec, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-purple-600 font-bold">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-slate-800">Explorador Interactivo</h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">
                    Haz clic en el galpón, la bodega, el estercolero o el filtro sanitario para inspeccionar sus especificaciones técnicas y criterios de bioseguridad.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Quick terrain summary card */}
          <div className="p-4 rounded-xl bg-purple-50/70 border border-purple-200/80 text-xs space-y-2">
            <span className="font-bold text-purple-950 block">Parámetros del Lote:</span>
            <div className="flex justify-between text-slate-600">
              <span>Dimensiones registradas:</span>
              <span className="font-mono font-semibold text-slate-900">{lotLength}m × {lotWidth}m</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Área total:</span>
              <span className="font-mono font-semibold text-slate-900">{terrain.totalArea} m²</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Topografía:</span>
              <span className="capitalize text-slate-900">{terrain.topography.replace('_', ' ')}</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
