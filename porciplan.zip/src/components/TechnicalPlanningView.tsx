import React, { useState } from 'react';
import { PorciProject, ProductiveOrientation, TechnicalZoneSpec } from '../types/project';
import { 
  Layers, 
  Wind, 
  Sun, 
  Droplets, 
  ShieldAlert, 
  Sparkles, 
  CheckCircle2, 
  Info, 
  Save, 
  ArrowRight,
  ClipboardList
} from 'lucide-react';

interface TechnicalPlanningViewProps {
  project: PorciProject;
  onUpdateTechnicalNotes: (notes: Record<string, string>) => void;
  onNavigateToNext: () => void;
}

export const TechnicalPlanningView: React.FC<TechnicalPlanningViewProps> = ({
  project,
  onUpdateTechnicalNotes,
  onNavigateToNext
}) => {
  const [technicalNotes, setTechnicalNotes] = useState<Record<string, string>>(project.technicalNotes || {});
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [selectedZoneId, setSelectedZoneId] = useState<string>('zone_galpon_principal');

  const orientation = project.characterization.orientation;

  const handleNoteChange = (key: string, value: string) => {
    const updated = { ...technicalNotes, [key]: value };
    setTechnicalNotes(updated);
  };

  const handleSave = () => {
    onUpdateTechnicalNotes(technicalNotes);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  // Structured technical zones based on established swine zootechnical requirements
  const zones: TechnicalZoneSpec[] = [
    {
      id: 'zone_galpon_principal',
      name: orientation === 'cria' 
        ? 'Nave de Maternidad y Parideras' 
        : orientation === 'ceba' 
        ? 'Nave de Levante y Ceba (Corrales Colectivos)' 
        : 'Nave Central de Producción Integrada',
      category: 'produccion' as const,
      description: orientation === 'cria'
        ? 'Área destinada a jaulas o parideras de bienestar, lechoneras con fuente de calor suplementario y pasillos de asistencia obstétrica.'
        : orientation === 'ceba'
        ? 'Corrales colectivos para lotes homogéneos (10 a 15 cerdos por corral), con división de zona seca de descanso y zona húmeda de deyecciones.'
        : 'Distribución modular de salas separadas por etapas (maternidad, destete y ceba) con paredes divisorias lavables e independientes.',
      orientationSuitability: ['cria', 'ceba', 'ciclo_completo'] as ProductiveOrientation[],
      recommendedFloor: 'Piso de concreto vaciado con estrías antideslizantes (pendiente 2.5% a 3%) o slats plásticos en zonas húmedas.',
      ventilationNotes: 'Orientación longitudinal Este-Oeste para mitigar radiación solar. Muros bajos (1.0m - 1.2m) con malla y cortinas regulables para ventilación natural.',
      waterDrainageNotes: 'Canaleta posterior de recolección de porcinaza con rejilla de separación y pendiente hacia fosa séptica/estercolero.'
    },
    {
      id: 'zone_gestacion_reproduccion',
      name: 'Área de Gestación y Cobertura',
      category: 'produccion' as const,
      description: 'Alojamiento para cerdas reproductoras en gestación y verraco/área de inseminación artificial.',
      orientationSuitability: ['cria', 'ciclo_completo'] as ProductiveOrientation[],
      recommendedFloor: 'Piso sólido de concreto de fácil lavado con cubículo individual o corrales para pequeños grupos.',
      ventilationNotes: 'Excelente circulación de aire fresco para evitar estrés calórico durante la preñez.',
      waterDrainageNotes: 'Desagües directos a línea de tratamiento de efluentes, sin encharcamientos.'
    },
    {
      id: 'zone_precebo_destete',
      name: 'Área de Precebo / Destete',
      category: 'produccion' as const,
      description: 'Recepción de lechones destetados (6 a 25 kg). Demanda mayor control térmico y piso cálido/seco para evitar diarreas mecánicas.',
      orientationSuitability: ['cria', 'ciclo_completo'] as ProductiveOrientation[],
      recommendedFloor: 'Piso de listones plásticos (slats) o cama profunda sobre concreto.',
      ventilationNotes: 'Ventilación controlada sin corrientes de aire directo a nivel de los lechones.',
      waterDrainageNotes: 'Drenaje por gravedad hacia fosa exterior con desinfección periódica.'
    },
    {
      id: 'zone_bodega_alimento',
      name: 'Bodega de Alimento Concentrado y Medicamentos',
      category: 'almacen' as const,
      description: 'Instalación cerrada y techada para almacenar sacos de concentrado sobre estibas plásticas o de madera, preservando la calidad organoléptica y nutricional.',
      orientationSuitability: ['cria', 'ceba', 'ciclo_completo'] as ProductiveOrientation[],
      recommendedFloor: 'Piso de concreto impermeabilizado y pulido, elevado mínimo 15cm sobre el nivel del suelo circundante.',
      ventilationNotes: 'Ambiente seco y ventilado con celosías a prueba de roedores y pájaros.',
      waterDrainageNotes: 'Sin contacto con aguas residuales ni canales de evacuación del galpón.'
    },
    {
      id: 'zone_bioseguridad_filtro',
      name: 'Filtro Sanitario y Pediluvio de Entrada',
      category: 'sanidad_ambiental' as const,
      description: 'Punto de control de bioseguridad obligatorio en el acceso: vado/pediluvio con desinfectante, vestier de cambio de calzado y lavado de manos.',
      orientationSuitability: ['cria', 'ceba', 'ciclo_completo'] as ProductiveOrientation[],
      recommendedFloor: 'Pozo o batea en concreto con profundidad de 10-15cm para líquido desinfectante.',
      ventilationNotes: 'Espacio de transición entre zona sucia exterior y zona limpia de producción.',
      waterDrainageNotes: 'Válvula de desagüe para recambio semanal o bisemanal de la solución desinfectante.'
    },
    {
      id: 'zone_manejo_porcinaza',
      name: 'Sistema de Tratamiento de Efluentes / Estercolero',
      category: 'sanidad_ambiental' as const,
      description: 'Estructura impermeabilizada (estercolero, fosa de sedimentación o biodigestor) ubicada en la parte más baja del lote para fermentación de sólidos y biofertilizante.',
      orientationSuitability: ['cria', 'ceba', 'ciclo_completo'] as ProductiveOrientation[],
      recommendedFloor: 'Tanque impermeabilizado con concreto hidrófugo o geomembrana para evitar lixiviados a aguas subterráneas.',
      ventilationNotes: 'Ubicado a sotavento (a favor del viento hacia afuera) para evitar que los olores ingresen a las áreas habitadas o naves.',
      waterDrainageNotes: 'Tubería cerrada en PVC sanitario de 4 o 6 pulgadas desde las canaletas de los galpones.'
    }
  ].filter(z => z.orientationSuitability.includes(orientation));

  const activeZone = zones.find(z => z.id === selectedZoneId) || zones[0];

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-purple-100 shadow-xs">
        <div>
          <span className="text-xs font-semibold text-purple-700 tracking-wider uppercase">Paso 03</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Planificación Técnica de Instalaciones</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Estructuración modular de las áreas requeridas para una explotación de{' '}
            <span className="font-semibold text-purple-900">
              {orientation === 'cria' ? 'Cría' : orientation === 'ceba' ? 'Levante y Ceba' : 'Ciclo Completo'}
            </span>{' '}
            con capacidad proyectada para <span className="font-semibold text-purple-900 font-mono">{project.characterization.animalCount} cerdos</span>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {savedSuccess && (
            <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
              <CheckCircle2 className="w-4 h-4" />
              <span>Anotaciones técnicas guardadas</span>
            </div>
          )}
          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-xl shadow-xs transition-colors flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Guardar Especificaciones</span>
          </button>
        </div>
      </div>

      {/* Foundational Bioclimatic & Zootechnical Principles */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-purple-100 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-purple-800 font-bold text-xs uppercase tracking-wider">
            <Sun className="w-4 h-4 text-amber-500" />
            <span>Orientación Solar (E-O)</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            El eje más largo del galpón debe alinearse de <strong>Este a Oeste</strong> en climas tropicales o templados. 
            Esto evita que el sol incida de frente sobre los cerdos en las horas más calurosas del día.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-purple-100 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-purple-800 font-bold text-xs uppercase tracking-wider">
            <Wind className="w-4 h-4 text-cyan-600" />
            <span>Ventilación Cruzada</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Aprovechar los vientos dominantes para renovación constante de aire sin generar corrientes frías directas al suelo. 
            Muros laterales a 1.0 m de altura con aleros de mínimo 80 cm para lluvia y sombra.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-purple-100 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-purple-800 font-bold text-xs uppercase tracking-wider">
            <Droplets className="w-4 h-4 text-purple-600" />
            <span>Pendiente y Drenaje Sanitario</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Pisos de corrales con <strong>pendiente continua del 2% al 3%</strong> orientada hacia el canal recolector posterior. 
            Permite lavado rápido y menor gasto de agua para mantener camas limpias y secas.
          </p>
        </div>
      </section>

      {/* Interactive Zone Explorer */}
      <section className="bg-white rounded-2xl border border-purple-100 shadow-xs overflow-hidden">
        <div className="p-6 border-b border-purple-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-purple-700" />
            <div>
              <h2 className="text-base font-bold text-slate-900">Módulos Funcionales de la Granja</h2>
              <p className="text-xs text-slate-500">Selecciona un área para revisar los criterios técnicos recomendados y registrar tus especificaciones.</p>
            </div>
          </div>
          <span className="text-xs font-mono text-purple-600 bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-100">
            {zones.length} módulos requeridos
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[420px]">
          
          {/* Zone Selector Sidebar */}
          <div className="lg:col-span-5 border-r border-purple-100 p-4 space-y-2 bg-purple-50/30">
            {zones.map((z, idx) => {
              const isSelected = z.id === activeZone.id;
              return (
                <button
                  key={z.id}
                  onClick={() => setSelectedZoneId(z.id)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 ${
                    isSelected
                      ? 'bg-white border-purple-400 text-purple-950 shadow-sm ring-1 ring-purple-600/20'
                      : 'bg-white/60 hover:bg-white border-slate-200/80 text-slate-700'
                  }`}
                >
                  <span className={`w-6 h-6 rounded-lg text-xs font-mono font-bold flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-purple-700 text-white' : 'bg-purple-100 text-purple-700'
                  }`}>
                    {idx + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-xs sm:text-sm font-bold truncate">{z.name}</h3>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{z.description}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Zone Detail & Technical Customization */}
          <div className="lg:col-span-7 p-6 space-y-5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] font-semibold text-purple-700 uppercase tracking-wider bg-purple-100 px-2 py-0.5 rounded-md">
                  {activeZone.category === 'produccion' ? 'Área Productiva' : activeZone.category === 'almacen' ? 'Soporte y Almacenamiento' : 'Bioseguridad y Ambiente'}
                </span>
              </div>
              <h3 className="text-lg font-bold text-purple-950">{activeZone.name}</h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">{activeZone.description}</p>
            </div>

            <div className="space-y-3 pt-2">
              <div className="p-3.5 rounded-xl bg-purple-50/50 border border-purple-100 space-y-1">
                <span className="text-[11px] font-bold text-purple-900 block">Tipo de Piso Recomendado:</span>
                <p className="text-xs text-slate-700">{activeZone.recommendedFloor}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-purple-50/50 border border-purple-100 space-y-1">
                <span className="text-[11px] font-bold text-purple-900 block">Ventilación y Clima:</span>
                <p className="text-xs text-slate-700">{activeZone.ventilationNotes}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-purple-50/50 border border-purple-100 space-y-1">
                <span className="text-[11px] font-bold text-purple-900 block">Drenaje y Evacuación:</span>
                <p className="text-xs text-slate-700">{activeZone.waterDrainageNotes}</p>
              </div>
            </div>

            {/* Custom Producer Note for this Area */}
            <div className="pt-2 border-t border-purple-50">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tus Especificaciones / Notas Particulares para este Módulo
              </label>
              <textarea
                rows={2}
                value={technicalNotes[activeZone.id] || ''}
                onChange={(e) => handleNoteChange(activeZone.id, e.target.value)}
                placeholder={`Anota dimensiones previstas, marcas de comederos, materiales locales a usar en ${activeZone.name}...`}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-600 text-slate-900"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Estas notas se conservan en tu proyecto y se reflejarán en el plano esquemático y el presupuesto.
              </span>
            </div>

          </div>

        </div>
      </section>

      {/* Integration Roadmap Callout */}
      <section className="p-6 rounded-2xl bg-gradient-to-r from-purple-50 via-purple-100/40 to-white border border-purple-200 space-y-3">
        <div className="flex items-center gap-2 text-purple-900 font-bold text-sm">
          <Sparkles className="w-4 h-4 text-purple-700" />
          <span>Fase Siguiente: Motor de Dimensionamiento Zootécnico e Integración con IA</span>
        </div>
        <p className="text-xs text-slate-700 leading-relaxed">
          Esta versión prototipo valida y organiza los parámetros iniciales de tu explotación de forma rigurosa y sin inventar fórmulas no certificadas. 
          En la siguiente versión se integrará el <strong>motor de cálculo zootécnico</strong> (área requerida por animal en m², número exacto de parideras o comederos según ciclo) 
          y asistencia contextual con <strong>Gemini</strong> para responder preguntas técnicas sobre sanidad porcina.
        </p>
      </section>

      {/* Navigation Footer */}
      <div className="flex justify-end gap-3 pt-2">
        <button
          type="button"
          onClick={handleSave}
          className="px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 transition-colors"
        >
          Guardar Cambios
        </button>
        <button
          type="button"
          onClick={() => {
            handleSave();
            onNavigateToNext();
          }}
          className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-xl shadow-xs transition-colors flex items-center gap-2"
        >
          <span>Ir a Diseño Esquemático 2D</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
