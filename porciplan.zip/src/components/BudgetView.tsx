import React, { useState } from 'react';
import { PorciProject, BudgetItem, BudgetCategory } from '../types/project';
import { 
  DollarSign, 
  Plus, 
  Trash2, 
  Save, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  TrendingUp, 
  TrendingDown, 
  RotateCcw,
  ArrowRight,
  FileSpreadsheet
} from 'lucide-react';

interface BudgetViewProps {
  project: PorciProject;
  onUpdateBudgetItems: (items: BudgetItem[]) => void;
  onNavigateToNext: () => void;
}

export const BudgetView: React.FC<BudgetViewProps> = ({
  project,
  onUpdateBudgetItems,
  onNavigateToNext
}) => {
  const [items, setItems] = useState<BudgetItem[]>(project.budgetItems || []);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // New item modal/inline form state
  const [isAdding, setIsAdding] = useState(false);
  const [newConcept, setNewConcept] = useState('');
  const [newCategory, setNewCategory] = useState<BudgetCategory>('obras_civiles');
  const [newUnit, setNewUnit] = useState('unidad');
  const [newQty, setNewQty] = useState<number>(1);
  const [newUnitCost, setNewUnitCost] = useState<number>(0);
  const [newNotes, setNewNotes] = useState('');
  const [addError, setAddError] = useState('');

  const currency = project.characterization.currency || 'COP';
  const availableBudget = project.characterization.availableBudget || 0;

  const totalCalculated = items.reduce((acc, curr) => acc + (curr.totalCost || 0), 0);
  const balance = availableBudget - totalCalculated;
  const isDeficit = balance < 0;

  const categoryLabels: Record<BudgetCategory, string> = {
    obras_civiles: 'Obras Civiles e Infraestructura',
    equipamiento: 'Equipamiento (Comederos / Bebederos)',
    hidraulico_electrico: 'Instalaciones Hidráulicas y Eléctricas',
    bioseguridad_ambiental: 'Bioseguridad y Manejo de Efluentes',
    imprevistos: 'Imprevistos y Fletes'
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newConcept.trim()) {
      setAddError('Por favor ingresa el concepto del rubro.');
      return;
    }
    if (newQty <= 0) {
      setAddError('La cantidad debe ser mayor a cero.');
      return;
    }
    if (newUnitCost < 0) {
      setAddError('El costo unitario no puede ser negativo.');
      return;
    }

    const newItem: BudgetItem = {
      id: `item_${Date.now()}`,
      category: newCategory,
      concept: newConcept.trim(),
      unit: newUnit.trim() || 'unidad',
      quantity: newQty,
      unitCost: newUnitCost,
      totalCost: newQty * newUnitCost,
      notes: newNotes.trim()
    };

    const updated = [...items, newItem];
    setItems(updated);
    onUpdateBudgetItems(updated);

    // Reset form
    setNewConcept('');
    setNewQty(1);
    setNewUnitCost(0);
    setNewNotes('');
    setAddError('');
    setIsAdding(false);
  };

  const handleDeleteItem = (id: string) => {
    const updated = items.filter(it => it.id !== id);
    setItems(updated);
    onUpdateBudgetItems(updated);
  };

  const handleManualSave = () => {
    onUpdateBudgetItems(items);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleLoadTemplate = () => {
    if (items.length > 0 && !confirm('¿Deseas recargar la plantilla básica sugerida? Esto reemplazará los rubros actuales.')) {
      return;
    }
    const templateItems: BudgetItem[] = [
      {
        id: `tpl_1`,
        category: 'obras_civiles',
        concept: 'Pisos de concreto afinado antideslizante con pendiente del 3%',
        unit: 'm²',
        quantity: 80,
        unitCost: 65000,
        totalCost: 5200000,
        notes: 'Espesor 10cm, malla electrosoldada'
      },
      {
        id: `tpl_2`,
        category: 'obras_civiles',
        concept: 'Muros perimetrales y divisiones en bloque o ladrillo (h=1.0m)',
        unit: 'm²',
        quantity: 40,
        unitCost: 48000,
        totalCost: 1920000
      },
      {
        id: `tpl_3`,
        category: 'obras_civiles',
        concept: 'Cubierta en teja termoacústica y perfilería estructural liviana',
        unit: 'm²',
        quantity: 95,
        unitCost: 72000,
        totalCost: 6840000
      },
      {
        id: `tpl_4`,
        category: 'equipamiento',
        concept: 'Comederos tipo tolva de acero inoxidable (capacidad 3-4 bocas)',
        unit: 'unidad',
        quantity: 3,
        unitCost: 650000,
        totalCost: 1950000
      },
      {
        id: `tpl_5`,
        category: 'equipamiento',
        concept: 'Bebederos tipo chupón de acero con base graduable y cazoleta',
        unit: 'unidad',
        quantity: 6,
        unitCost: 35000,
        totalCost: 210000
      },
      {
        id: `tpl_6`,
        category: 'hidraulico_electrico',
        concept: 'Tanque plástico de almacenamiento de agua 2.000 L y tuberías PVC',
        unit: 'global',
        quantity: 1,
        unitCost: 1750000,
        totalCost: 1750000
      },
      {
        id: `tpl_7`,
        category: 'bioseguridad_ambiental',
        concept: 'Estercolero impermeabilizado con trampa de sedimentación',
        unit: 'unidad',
        quantity: 1,
        unitCost: 2800000,
        totalCost: 2800000
      },
      {
        id: `tpl_8`,
        category: 'bioseguridad_ambiental',
        concept: 'Pediluvio sanitario en acceso y valla perimetral básica',
        unit: 'global',
        quantity: 1,
        unitCost: 850000,
        totalCost: 850000
      },
      {
        id: `tpl_9`,
        category: 'imprevistos',
        concept: 'Imprevistos de obra y transporte de materiales (5%)',
        unit: 'global',
        quantity: 1,
        unitCost: 1000000,
        totalCost: 1000000
      }
    ];
    setItems(templateItems);
    onUpdateBudgetItems(templateItems);
  };

  const filteredItems = selectedCategory === 'all'
    ? items
    : items.filter(it => it.category === selectedCategory);

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      
      {/* Header with status */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-purple-100 shadow-xs">
        <div>
          <span className="text-xs font-semibold text-purple-700 tracking-wider uppercase">Paso 05</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Presupuesto Estimado del Proyecto</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Planifica y desglosa los rubros reales de obra, equipos y bioseguridad para mantener el control financiero.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {saveSuccess && (
            <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
              <CheckCircle2 className="w-4 h-4" />
              <span>Presupuesto guardado</span>
            </div>
          )}
          <button
            onClick={handleManualSave}
            className="px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl border border-purple-200 text-purple-900 bg-purple-50 hover:bg-purple-100 transition-colors flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Guardar Cambios</span>
          </button>
          <button
            onClick={onNavigateToNext}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-xl shadow-xs transition-colors flex items-center gap-2"
          >
            <span>Ver Resultados</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Cards: Available vs Total vs Balance */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="p-5 rounded-2xl bg-white border border-purple-100 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Presupuesto Disponible Registrado</span>
          <div className="text-xl sm:text-2xl font-bold text-purple-950 font-mono tabular-nums">
            {currency} ${Number(availableBudget).toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-400 block">Definido en la caracterización inicial</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-purple-100 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Total Presupuestado en Rubros</span>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {currency} ${Number(totalCalculated).toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-400 block">{items.length} conceptos detallados</span>
        </div>

        <div className={`p-5 rounded-2xl border shadow-xs space-y-1 ${
          isDeficit 
            ? 'bg-rose-50/70 border-rose-200 text-rose-950' 
            : 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
        }`}>
          <span className="text-xs font-semibold block">
            {isDeficit ? 'Déficit / Financiamiento Requerido' : 'Saldo Disponible (Superávit)'}
          </span>
          <div className="text-xl sm:text-2xl font-bold font-mono tabular-nums flex items-center gap-2">
            {isDeficit ? <TrendingDown className="w-5 h-5 text-rose-600" /> : <TrendingUp className="w-5 h-5 text-emerald-600" />}
            <span>{currency} ${Math.abs(balance).toLocaleString()}</span>
          </div>
          <span className="text-[11px] opacity-80 block">
            {isDeficit 
              ? 'Los costos superan el presupuesto actual disponible.' 
              : 'El proyecto se encuentra dentro del margen de presupuesto.'}
          </span>
        </div>

      </div>

      {/* Categories Filter & Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 bg-purple-50/70 rounded-2xl border border-purple-100 text-xs">
        
        {/* Category Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-white text-purple-950 shadow-xs font-bold'
                : 'text-slate-600 hover:text-purple-900'
            }`}
          >
            Todos ({items.length})
          </button>
          {(Object.keys(categoryLabels) as BudgetCategory[]).map((cat) => {
            const count = items.filter(it => it.category === cat).length;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-white text-purple-950 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-purple-900'
                }`}
              >
                {categoryLabels[cat].split('(')[0].trim()} ({count})
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAdding(true)}
            className="px-3.5 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Agregar Rubro</span>
          </button>
          <button
            onClick={handleLoadTemplate}
            className="px-3 py-1.5 rounded-xl border border-purple-200 bg-white hover:bg-purple-50 text-purple-900 font-medium transition-colors flex items-center gap-1"
            title="Cargar catálogo estándar de rubros porcinos"
          >
            <RotateCcw className="w-3.5 h-3.5 text-purple-600" />
            <span className="hidden sm:inline">Cargar Guía Sugerida</span>
          </button>
        </div>

      </div>

      {/* Add New Item Form Modal / Drawer */}
      {isAdding && (
        <form onSubmit={handleAddItem} className="bg-white p-6 rounded-2xl border border-purple-200 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-purple-50 pb-3">
            <h3 className="text-sm font-bold text-purple-950">Agregar Nuevo Rubro de Gasto</h3>
            <button
              type="button"
              onClick={() => { setIsAdding(false); setAddError(''); }}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Cerrar
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Concepto / Descripción del Item *</label>
              <input
                type="text"
                value={newConcept}
                onChange={(e) => setNewConcept(e.target.value)}
                placeholder="Ej. Tubería galvanizada para cerchas de techo"
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-600 text-slate-900"
                autoFocus
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Categoría</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as BudgetCategory)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-600 text-slate-900"
              >
                {(Object.keys(categoryLabels) as BudgetCategory[]).map(cat => (
                  <option key={cat} value={cat}>{categoryLabels[cat]}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Unidad de Medida</label>
              <input
                type="text"
                value={newUnit}
                onChange={(e) => setNewUnit(e.target.value)}
                placeholder="m², unidad, global, ml"
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-600 text-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Cantidad *</label>
              <input
                type="number"
                min="0.1"
                step="any"
                value={newQty || ''}
                onChange={(e) => setNewQty(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-600 text-slate-900 font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Costo Unitario ({currency}) *</label>
              <input
                type="number"
                min="0"
                step="any"
                value={newUnitCost || ''}
                onChange={(e) => setNewUnitCost(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-600 text-slate-900 font-mono tabular-nums"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Total Estimado</label>
              <div className="px-3 py-2 rounded-xl bg-purple-50 border border-purple-200 text-purple-950 font-bold font-mono">
                {currency} ${(newQty * newUnitCost).toLocaleString()}
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Notas / Proveedor</label>
              <input
                type="text"
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                placeholder="Proveedor local, especificación técnica..."
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-600 text-slate-900"
              />
            </div>

          </div>

          {addError && <p className="text-xs text-red-600">{addError}</p>}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => { setIsAdding(false); setAddError(''); }}
              className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-900"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-xl shadow-xs transition-colors"
            >
              Guardar Rubro
            </button>
          </div>
        </form>
      )}

      {/* Budget Table */}
      <div className="bg-white rounded-2xl border border-purple-100 shadow-xs overflow-hidden">
        {filteredItems.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-800">No hay rubros en esta categoría</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                Agrega un nuevo concepto o carga la guía de rubros estándar para comenzar a estimar tus costos.
              </p>
            </div>
            <button
              onClick={() => setIsAdding(true)}
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-xl shadow-xs transition-colors"
            >
              Agregar Rubro
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-purple-50/70 border-b border-purple-100 text-slate-700 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Concepto y Especificación</th>
                  <th className="py-3 px-4">Categoría</th>
                  <th className="py-3 px-3 text-right">Cant.</th>
                  <th className="py-3 px-3 text-center">Unidad</th>
                  <th className="py-3 px-3 text-right">Costo Unit. ({currency})</th>
                  <th className="py-3 px-4 text-right">Total ({currency})</th>
                  <th className="py-3 px-3 text-center">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-purple-50">
                {filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-purple-50/30 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{item.concept}</div>
                      {item.notes && <div className="text-[11px] text-slate-500 mt-0.5">{item.notes}</div>}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[11px] font-medium text-purple-800 bg-purple-50 px-2 py-0.5 rounded-md">
                        {categoryLabels[item.category]?.split('(')[0].trim() || item.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-medium text-slate-800">
                      {item.quantity}
                    </td>
                    <td className="py-3 px-3 text-center text-slate-500 font-mono">
                      {item.unit}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                      ${Number(item.unitCost).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-purple-950">
                      ${Number(item.totalCost).toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => handleDeleteItem(item.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                        title="Eliminar rubro"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-purple-50/80 border-t-2 border-purple-200 font-bold text-slate-900">
                <tr>
                  <td colSpan={5} className="py-3 px-4 text-right uppercase text-[11px] tracking-wider text-purple-950">
                    Total Presupuestado ({filteredItems.length} rubros):
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-sm text-purple-950">
                    ${Number(filteredItems.reduce((acc, it) => acc + it.totalCost, 0)).toLocaleString()}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
